# global os
__version__ = '0.0.6'
__author__ = 'Jeff Terry, Alaina Humiston, Miu Lun Lau, Min Long'
__email__ = 'terryj@iit.edu, thompson9@hawk.iit.edu, andylau@u.boisestate.edu, minlong@boisestate.edu'


# Note
# variables only get save in __init__.py, but not everywhere else.
# variable does get save across, this show be the final location for running the script

#
